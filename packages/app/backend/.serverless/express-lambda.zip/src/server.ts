import express, { Request, Response } from "express";
import dotenv from "dotenv";
import cors, { CorsOptions } from "cors";
import serverless from "serverless-http";

const allowedOrigin = {
  development: ["http://localhost:5173/portfolio/"],
  production: ["https://kylerhansen.github.io/portfolio/"],
};

export enum HttpStatusCode {
  Ok = 200,
  BadRequest = 400,
  GenericServerError = 500,
}

dotenv.config();

const app = express();

const env =
  process.env.NODE_ENV === "development" ? "development" : "production";

const corsOptions: CorsOptions = {
  methods: ["GET", "POST"],
  origin: allowedOrigin[env] || [],
};

app.use(cors(corsOptions));

app.use(express.json());

app.get("/health", (req: Request, res: Response) => {
  res.sendStatus(HttpStatusCode.Ok);
});

app.post("/askJarvis", (req: Request, res: Response) => {
  res.sendStatus(HttpStatusCode.Ok);
});

export const handler = serverless(app);

/**
 * HERE:
 * tsc is not compiling correctly which means tsconfigs are off
 * its not excluding node_modules
 *
 * using this video as a guide.
 * https://www.youtube.com/watch?v=BRRxQbSb9bo
 *
 * I believe aws lambda is set up correctly because its complaining about the express import
 * in this file meaning its finding it.
 *
 * I was working on adjusting the serverless.yml file to have it find the correct function path.
 * go to cloud watch monitor view cloud watch logs.
 */
